export class Customer {
  id: string;
  name: string;
  email: string;
  createdAt: Date;
}
